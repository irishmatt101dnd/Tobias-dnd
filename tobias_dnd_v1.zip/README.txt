TOBIAS D&D — V1
Open index.html in a browser/hosted site. The app stores character changes and rolls in the browser's local storage.
For iPhone installation, the app should be hosted at a web address, then opened in Safari and added to the Home Screen.
